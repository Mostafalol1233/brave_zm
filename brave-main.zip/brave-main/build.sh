#!/bin/bash

# تثبيت الاعتماديات
npm install

# بناء التطبيق
npm run build